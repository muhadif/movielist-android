package com.muhadif.appmovie.data.models;

public class Genre {
}
