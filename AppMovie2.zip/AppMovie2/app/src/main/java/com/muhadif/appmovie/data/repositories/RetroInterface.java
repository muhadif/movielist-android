package com.muhadif.appmovie.data.repositories;

import com.muhadif.appmovie.BuildConfig;
import com.muhadif.appmovie.data.models.ResultModel;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RetroInterface {
    public static final String API_KEY = BuildConfig.API_KEY;

    @GET("3/movie/now_playing?api_key=" + API_KEY + "&page=1")
    public Call<ResultModel> getNowPlaying();
}
